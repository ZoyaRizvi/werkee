export * from "@/pages/dashboard/home";
export * from "@/pages/dashboard/profile";
export * from "@/pages/dashboard/chat";
export * from "@/pages/dashboard/notifications";
export * from  "@/pages/dashboard/posting";